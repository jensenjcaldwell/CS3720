import pandas as pd

def load_data_pandas(file_path):
    """
    Load data from a CSV file into a pandas DataFrame.
    
    Parameters:
    file_path (str): The path to the CSV file.
    
    Returns:
    pd.DataFrame: The loaded data as a pandas DataFrame.
    """
    try:
        data_frame = pd.read_csv(file_path)
        return data_frame
    except Exception as e:
        print(f"An error occurred while loading the data: {e}")
        return None
    
def df_details(df):
    """
    Print details about the DataFrame.
    
    Parameters:
    df (pd.DataFrame): The DataFrame to analyze.
    """
    print("DataFrame Info:")
    print(df.info())
    print("\nDataFrame Description:")
    print(df.describe())
    print("\nMissing Values in Each Column:")
    print(df.isnull().sum())
    print("\n Number of rows and columns:")
    print(df.shape)


if __name__ == "__main__":
    # Example usage
    file_path = './data/Weather Training Data.csv'  # Replace with your CSV file path
    df = load_data_pandas(file_path)
    if df is not None:
        print("Data loaded successfully:")
        df_details(df)