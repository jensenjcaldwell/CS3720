import MyModule as my_package

if __name__ == "__main__":
    # Example usage
    file_path = 'data/Weather Training Data.csv'  # Replace with your CSV file path
    df = my_package.load_data_pandas(file_path)
    
    if df is not None:
        print("Data loaded successfully.")
        missing_summary = my_package.missing_values_summary(df)
        print(missing_summary)
        print("\nDataFrame Details:")
        my_package.df_details(df)
        