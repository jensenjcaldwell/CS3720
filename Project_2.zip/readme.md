# Asignment 1
This project uses weather data to observe and predict weather trends

## Data souces

All data was sourced from the Kaggle Australia Weather Data set and can be found [here](https://www.kaggle.com/datasets/arunavakrchakraborty/australia-weather-data)

## Functions

    df_details(df)
        Print details about the DataFrame.

        Parameters:
            df (pd.DataFrame): The DataFrame to analyze.

    column_stats(df, column)
        Calculate and display statistics for a specific column in the DataFrame.

        Parameters:
            df (pd.DataFrame): The DataFrame containing the column.

        Returns:
            A dataframe containing various statistics about each column

    missing_values_summary
        Calculates number of missing values in each column

        Parameters:
            df (pd.DataFrame): The DataFrame to analyze.

        Returns:
            A dataframe containing number of missing values in each column
    
    load_data_pandas(file_path)
        Load data from a CSV file into a pandas DataFrame.
 
        Parameters:
            file_path (str): The path to the CSV file.
        
        Returns:
            pd.DataFrame: The loaded data as a pandas DataFrame.

