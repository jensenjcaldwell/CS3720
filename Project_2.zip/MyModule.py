import pandas as pd

def load_data_pandas(file_path):
    """
    Load data from a CSV file into a pandas DataFrame.
    
    Parameters:
    file_path (str): The path to the CSV file.
    
    Returns:
    pd.DataFrame: The loaded data as a pandas DataFrame.
    """
    try:
        data_frame = pd.read_csv(file_path)
        return data_frame
    except Exception as e:
        print(f"An error occurred while loading the data: {e}")
        return None
    
def df_details(df):
    """
    Print details about the DataFrame including info, description, missing values, and shape.
    
    Parameters:
    df (pd.DataFrame): The DataFrame to analyze.
    """
    print("DataFrame Info:")
    print(df.info())
    print("\nDataFrame Description:")
    print(df.describe())
    print("\nMissing Values in Each Column:")
    print(df.isnull().sum())
    print("\n Number of rows and columns:")
    print(df.shape)

def column_stats(df):
    """
    Print statistics for each column in the DataFrame.
    
    Parameters:
    df (pd.DataFrame): The DataFrame to analyze.
    """
    for column in df.columns:
        print(f"\nStatistics for column: {column}")
        print(df[column].describe())

def missing_values_summary(df):
    """
    Print a summary of missing values in the DataFrame.
    
    Parameters:
    df (pd.DataFrame): The DataFrame to analyze.
    """
    missing_values = df.isnull().sum()
    total_missing = missing_values.sum()
    print(f"Total missing values in DataFrame: {total_missing}")
    print("Missing values per column:")
    print(missing_values[missing_values > 0])


if __name__ == "__main__":
    # Example usage
    file_path = './data/Weather Training Data.csv'  # Replace with your CSV file path
    df = load_data_pandas(file_path)
    if df is not None:
        print("Data loaded successfully:")
        df_details(df)
        print(df.head())  # Display the first few rows of the DataFrame